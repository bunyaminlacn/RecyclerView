package com.example.cardviewtasarimi

data class Filmler (var film_id:Int,var filim_ad:String,var film_resim_ad:String,var film_fiyat:Double){
}